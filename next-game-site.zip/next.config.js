module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['www.freetogame.com', 'www.cloudinary.com', 'www.res.cloudinary.com'],
  },
}
