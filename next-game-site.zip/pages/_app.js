import Layout from '../components/Layout';
import '../styles/globals.css'
import 'bootstrap/dist/css/bootstrap.css'
import '../styles/elegant-icons.css';
import '../styles/font-awesome.min.css';
import '../styles/nice-select.css';
import '../styles/owl.carousel.min.css';
import '../styles/plyr.css';
import '../styles/slicknav.min.css';
import '../styles/style.css';



function MyApp({ Component, pageProps }) {
  return (
    <Layout>
      <Component {...pageProps} />
    </Layout>
  );
}

export default MyApp
