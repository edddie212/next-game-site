import GameList from "../components/GameList";
import GameCategorySidebar from "../components/GameCategorySidebar";
import HomeSlider from "../components/HomeSlider";
import { server } from "../config";

export default function Home({ games, categories }) {

  return (
    <>
      <section className="hero">
        <HomeSlider />
        <section className="product spad">
          <div className="container">
            <div className="row">
              <div className="col-lg-8">
                <div className="trending__product">
                  <div className="row">
                    <div className="col-lg-8 col-md-8 col-sm-8">
                      <div className="section-title">
                        <h4>Trending Now</h4>
                      </div>
                    </div>
                  </div>
                  <div className="row">
                    <GameList games={games} />
                  </div>
                </div>
              </div>

              <div className="col-lg-4 col-md-6 col-sm-8">
                <GameCategorySidebar categories={categories} />
              </div>
            </div>
          </div>
        </section>

        <div className="clear-fix"></div>
      </section>
    </>
  );
}

export const getStaticProps = async () => {
  const categoryRes = await fetch(`${server}/api/categories`);
  const res = await fetch(
    `https://free-to-play-games-database.p.rapidapi.com/api/games`,
    {
      methods: "GET",
      headers: {
        "x-rapidapi-host": "free-to-play-games-database.p.rapidapi.com",
        "x-rapidapi-key": "2f38357328msh897085dc58b7fb1p170b67jsn9fe8508d29c2",
      },
    }
  );

  const games = await res.json();
  const categories = await categoryRes.json();

  return {
    props: {
      games,
      categories,
    },
  };
};
